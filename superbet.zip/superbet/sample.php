<?php
    echo "Hello";
?>